#!/bin/bash
#Script Update
#Starts Here

#Colours
R='\e[31m'
C='\e[36m'
G='\e[92m'
E='\e[0m'
                             #INTRO

echo -e " $G
                                        _       _       
                        /\ /\ _ __   __| | __ _| |_ ___ 
                       / / \ \ '_ \ / _` |/ _` | __/ _ \
                       \ \_/ / |_) | (_| | (_| | ||  __/
                        \___/| .__/ \__,_|\__,_|\__\___|
                             |_|                        $E"
sleep 1.5
echo -e "$R                         ChecKing For 2.0 $E"
sleep 1.5
echo -e "$C                         ChecKing For 2.0 $E"
sleep 1.5
echo -e "$G                           Update Found!!!   $E"
sleep 1.5

echo -e "$G                          Updating VirusX5  $E"
cd $HOME
rm -rf VirusX5
git clone https://github.com/Zaeem20/VirusX5
cd VirusX5
unzip VirusX5.zip
chmod +x *

echo -e "$C                        SucessFully Updated VirusX5 $E"
echo 
echo -e "$G                           Returning to VirusX5 $E"
sleep 2.0
bash Virus.sh
